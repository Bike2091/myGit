package com.example.lab7.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="address")
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String address_line1;
    private String address_line2;
    private String Zipcode;

    @OneToOne(mappedBy = "address")
    private Customer customer;

    public Address(){
        
    }

    public Address(Long id, String address_line1, String address_line2, String zipcode, Customer customer) {
        this.id = id;
        this.address_line1 = address_line1;
        this.address_line2 = address_line2;
        Zipcode = zipcode;
        this.customer = customer;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getAddress_line1() {
        return address_line1;
    }
    public void setAddress_line1(String address_line1) {
        this.address_line1 = address_line1;
    }
    public String getAddress_line2() {
        return address_line2;
    }
    public void setAddress_line2(String address_line2) {
        this.address_line2 = address_line2;
    }
    public String getZipcode() {
        return Zipcode;
    }
    public void setZipcode(String zipcode) {
        Zipcode = zipcode;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return address_line1 + " " + address_line2 + " " + Zipcode;
    }

}