package com.example.lab7.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.lab7.model.Category;
import com.example.lab7.model.Product;
import com.example.lab7.service.CategoryService;
import com.example.lab7.service.CustomerService;
import com.example.lab7.service.ProductService;


@Controller
public class WebController {

    @Autowired
    CustomerService customerService;

    @Autowired
    CategoryService categoryService;

    @Autowired
    ProductService productService;

    @RequestMapping("/")
    public String getRoot() {
        return "index";
    }
    

    @GetMapping("/customer")
    public String showCustomer(Model model) {
        model.addAttribute("customer", customerService.findAll());
        return "showCustomer";
    }

    @GetMapping("/category")
    public String showCategory(Model model) {
        model.addAttribute("category", categoryService.findAll());
        return "showCategory";
    }

    @GetMapping("/product")
    public String showProduct(Model model) {
        model.addAttribute("product", productService.findAll());
        return "showProduct";
    }

    @GetMapping("/addCategory")
    public String addCategory(Model model) {
        model.addAttribute("category", new Category());
        return "addCategory";
    }

    @PostMapping("/addCategory")
    public String submitCategory(@ModelAttribute("category") Category category) {
        categoryService.save(category);
        return "savedCategory";
    }

    @GetMapping("/addProduct")
    public String showAddProductForm(Model model) {
        model.addAttribute("category", productService.getAllCategories());
        return "addProduct";
    }

    @PostMapping("/addProduct")
    public String submitCategory(@ModelAttribute("product") Product product) {
        productService.save(product);
        return "savedProduct";
    }

    @GetMapping("/category/edit/{id}")
    public String showEditCategory(@PathVariable("id") Long id, Model model) {
        model.addAttribute("category", categoryService.findById(id));
        return "editCategory";
    }

    @PostMapping("/category/update/{id}")
    public String updatecategory(@PathVariable("id") Long id, @ModelAttribute Category category) {
        category.setId(id);
        categoryService.save(category);
        return "redirect:/category";
    }

    @GetMapping("/category/delete/{id}")
    public String deletecategory(@PathVariable("id") Long id) {
        categoryService.deletecategoryById(id);
        return "redirect:/category";
    }

    @GetMapping("/product/edit/{id}")
    public String showEditProduct(@PathVariable("id") Long id, Model model) {
        model.addAttribute("product", productService.findProductById(id));
        model.addAttribute("category", productService.getAllCategories());
        return "editProduct";
    }

    @PostMapping("/product/update/{id}")
    public String updateproduct(@PathVariable("id") Long id, @ModelAttribute Product product) {
        product.setId(id);
        productService.save(product);
        return "redirect:/product";
    }

    @GetMapping("/product/delete/{id}")
    public String deleteproduct(@PathVariable("id") Long id) {
        productService.deleteproductById(id);
        return "redirect:/product";
    }

}
