package com.example.lab7.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table(name = "category")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy = "category",cascade = CascadeType.ALL)
    private List<Product> Product;

    public Category(){
        
    }

    public Category(Long id, String name, List<Product> product) {
        this.id = id;
        this.name = name;
        Product = product;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Product> getProduct() {
        return Product;
    }

    public void setProduct(List<Product> product) {
        Product = product;
    }

    @Override
    public String toString() {
        return "Category [id=" + id + ", name=" + name + ", Product=" + Product + "]";
    }
    
}
