package com.example.lab7.repository;

import org.springframework.data.repository.CrudRepository;
import com.example.lab7.model.Address;

public interface AddressRepository  extends CrudRepository<Address, Long>{
    
}
